﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace finalPOE
{
    
    public partial class ViewRecipe : Page
    {
        private List<Recipe> recipes;

        public ViewRecipe(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            DisplayRecipeNames();
        }

        private void DisplayRecipeNames()
        {
            var sortedRecipeNames = recipes.Select(r => r.Name).OrderBy(name => name).ToList();
            RecipeNamesTextBlock.Text = string.Join("\n", sortedRecipeNames);
        }

        private void ViewRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            DisplayAllRecipeDetails();
        }

        private void DisplayAllRecipeDetails()
        {
            StringBuilder sb = new StringBuilder();
            foreach (var recipe in recipes)
            {
                sb.AppendLine($"Name: {recipe.Name}");
                sb.AppendLine($"Ingredients: {recipe.Ingredients}");
                sb.AppendLine($"Food Group: {recipe.FoodGroup}");
                sb.AppendLine($"Quantity: {recipe.Quantity}");
                sb.AppendLine($"Calories: {recipe.Calories}");
                sb.AppendLine($"Steps: {recipe.Steps}");
                sb.AppendLine(new string('-', 40)); // Separator between recipes
            }
            RecipeDetailsTextBlock.Text = sb.ToString();
        }
    }
}