﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace finalPOE
{
    
   
        public partial class AddRecipe : Page
{
    private List<Recipe> recipes;
    private Recipe currentRecipe;

    public AddRecipe(List<Recipe> recipes)
    {
        InitializeComponent();
        this.recipes = recipes;
        currentRecipe = new Recipe();
    }

            public void RecipeName1_TextChanged(object sender, TextChangedEventArgs e)
        {
            currentRecipe.Name = ((TextBox)sender).Text;
        }

        public void Ingredients_TextChanged(object sender, TextChangedEventArgs e)
        {
            currentRecipe.Ingredients = ((TextBox)sender).Text;
        }

        public void FoodGroup_TextChanged(object sender, TextChangedEventArgs e)
        {
            currentRecipe.FoodGroup = ((TextBox)sender).Text;
        }

        public void Quantity_TextChanged(object sender, TextChangedEventArgs e)
        {
            currentRecipe.Quantity = ((TextBox)sender).Text;
        }

        public void Calories_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (int.TryParse(((TextBox)sender).Text, out int calories))
            {
                currentRecipe.Calories = calories;
                if (calories > 300)
                {
                    MessageBox.Show("The calorie count exceeds 300!", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
            else
            {
                // Handle the error: You might want to reset the value, show a message, etc.
                currentRecipe.Calories = 0; // or some default value
                                       
            }
        }


        public void Steps_TextChanged(object sender, TextChangedEventArgs e)
        {
            currentRecipe.Steps = ((TextBox)sender).Text;
        }

        public void Button_Click(object sender, RoutedEventArgs e)
        {
            recipes.Add(new Recipe
            {
                Name = currentRecipe.Name,
                Ingredients = currentRecipe.Ingredients,
                FoodGroup = currentRecipe.FoodGroup,
                Quantity = currentRecipe.Quantity,
                Calories = currentRecipe.Calories,
                Steps = currentRecipe.Steps
            });
            currentRecipe = new Recipe();
           // ClearInputFields();

            // Navigate to the HomePage
            NavigationService navService = NavigationService.GetNavigationService(this);
            if (navService != null)
            {
                navService.Navigate(new Uri("HomePage.xaml", UriKind.Relative));
            }
        }

        private void ClearInputFields()
        {
            RecipeName1.Text = string.Empty;
            Ingredients.Text = string.Empty;
            FoodGroup.Text = string.Empty;
            Quantity.Text = string.Empty;
            Calories.Text = string.Empty;
            Steps.Text = string.Empty;
        }
    }
}

 
