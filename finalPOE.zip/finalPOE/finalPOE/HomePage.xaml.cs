﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace finalPOE
{
    
    public partial class HomePage : Page
    {
        public List<Recipe> recipes = new List<Recipe>();
        public HomePage()
        {
            InitializeComponent();
        }

        public void AddRbutton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new AddRecipe(recipes));
        }

        public void ViewRbutton_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(new ViewRecipe(recipes));
        }
        public void AddExampleRecipes()
        {
            recipes.Add(new Recipe
            {
                Name = "Spaghetti Bolognese",
                Ingredients = "Spaghetti, minced beef, tomato sauce",
                FoodGroup = "Pasta",
                Quantity = "2 servings",
                Calories = 600,
                Steps = "1. Cook spaghetti.\n2. Prepare sauce.\n3. Combine and serve."
            });
            recipes.Add(new Recipe
            {
                Name = "Caesar Salad",
                Ingredients = "Lettuce, croutons, Caesar dressing",
                FoodGroup = "Salad",
                Quantity = "1 serving",
                Calories = 200,
                Steps = "1. Mix ingredients.\n2. Add dressing.\n3. Toss and serve."
            });
        }

        public void Frame_Navigated(object sender, NavigationEventArgs e)
        {
        }

    public void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            recipes.Clear();
            MessageBox.Show("All recipes have been deleted.", "Confirmation", MessageBoxButton.OK, MessageBoxImage.Information);

        }
        private void RateRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new RateRecipe(recipes));
        }

        public void endButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }



}
