﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finalPOE
{
    public class Recipe
    {
        public string Name { get; set; }
        public string Ingredients { get; set; }
        public string FoodGroup { get; set; }
        public string Quantity { get; set; }
        public int Calories { get; set; }
        public string Steps { get; set; }
        public double Rating { get; set; }
    }
}
