﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace finalPOE
{
    public partial class RateRecipe : Page
    {
        private List<Recipe> recipes;

        public RateRecipe(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            LoadRecipeNames();
        }

        private void LoadRecipeNames()
        {
            RecipeComboBox.ItemsSource = recipes;
            RecipeComboBox.DisplayMemberPath = "Name"; // Display the recipe name in the ComboBox
        }

        private void SubmitRatingButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeComboBox.SelectedItem is Recipe selectedRecipe)
            {
                selectedRecipe.Rating = RatingSlider.Value;
                StatusTextBlock.Text = $"You rated {selectedRecipe.Name} with {RatingSlider.Value} stars.";
            }
            else
            {
                StatusTextBlock.Text = "Please select a recipe to rate.";
            }
        }
    }
}
